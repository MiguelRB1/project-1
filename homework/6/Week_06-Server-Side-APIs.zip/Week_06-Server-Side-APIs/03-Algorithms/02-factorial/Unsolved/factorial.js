// Write code to create a function that returns the factorial of `num`

var factorial = function(num) {};
