Instruction will demostrate this in the browser console.
https://developer.mozilla.org/en-US/docs/Web/API/Document/location

