# cURL Demo

In this activity, you will demonstrate how to use cURL in the terminal.

## Instructions

* Open your terminal and type `curl https://api.github.com/users`.

  * This should return a list of the last 30 users who made a profile

  [//]: # (*going to a url in teh browser adn hittp and pressing enter is making an automatic API request)